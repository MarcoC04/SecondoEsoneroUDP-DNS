#ifndef PROTOCOL_H
#define PROTOCOL_H

#define BUFFMAX 255 // this define the size of the buffer
#define DEFAULT_IP "127.0.0.1" //here is defined the default ip
#define DEFAULT_SERVER "passwdgen.uniba.it" //here is defined the name associated to the default ip
#define DEFAULT_PORT 48000 //this define the default port
#define NO_ERROR 0 //this is like a "variable" used into some ifs

// Minimum and maximum password length
#define MIN_LENGTH 6
#define MAX_LENGTH 32

// Commands
#define CMD_HELP 'h'
#define CMD_QUIT 'q'
#define CMD_NUMERIC 'n'
#define CMD_ALPHA 'a'
#define CMD_MIXED 'm'
#define CMD_SECURE 's'
#define CMD_UNAMBIGUOUS 'u'


// this is the struct for the protocol requests
typedef struct {
    char request_type;
    int length;
    char password[MAX_LENGTH + 1];
} request;

#endif // PROTOCOL_H



