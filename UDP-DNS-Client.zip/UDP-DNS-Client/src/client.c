#include "protocol.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#if defined WIN32
#include <winsock2.h>
#include <ws2tcpip.h>
#include <windows.h>
#else
#include <arpa/inet.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#define closesocket close
#endif

// Function to clean up the Winsock library on Windows
void clearwinsock()
{
#if defined WIN32
    WSACleanup();
#endif
}

// Function to handle errors by printing error messages
void errorhandler(const char *error_message)
{
    perror(error_message);
}

// Function to display the main menu of the client
void print_menu()
{
    printf("Password Generator Menu\n");
    printf("Commands:\n");
    printf(" h        : show this help menu\n");
    printf(" n LENGTH : generate numeric password\n");
    printf(" a LENGTH : generate alphabetic password\n");
    printf(" m LENGTH : generate mixed password\n");
    printf(" s LENGTH : generate secure password\n");
    printf(" u LENGTH : generate unambiguous secure password\n");
    printf(" q        : quit application\n");
}

// Function to display the help menu with detailed descriptions of each command
void print_help_menu()
{
    printf("Password Generator Help Menu\n");
    printf("Commands:\n");
    printf(" h        : show this help menu\n");
    printf(" n LENGTH : generate numeric password (digits only)\n");
    printf(" a LENGTH : generate alphabetic password (lowercase letters)\n");
    printf(" m LENGTH : generate mixed password (lowercase letters and numbers)\n");
    printf(" s LENGTH : generate secure password (uppercase, lowercase, numbers, symbols)\n");
    printf(" u LENGTH : generate unambiguous secure password (no similar-looking characters)\n");
    printf(" q        : quit application\n");
    printf("\n LENGTH must be between %d and %d characters\n", MIN_LENGTH, MAX_LENGTH);
    printf("\nAmbiguous characters excluded in 'u' option:\n");
    printf(" 0 O o (zero and letters O)\n");
    printf(" 1 l I i (one and letters l, I)\n");
    printf(" 2 Z z (two and letter Z)\n");
    printf(" 5 S s (five and letter S)\n");
    printf(" 8 B (eight and letter B)\n");
}

int main(void)
{
#if defined WIN32
    WSADATA wsa_data;
    if (WSAStartup(MAKEWORD(2, 2), &wsa_data) != 0) {
        errorhandler("Error at WSAStartup()");
        return 0;
    }
#endif

    const char *server_name = DEFAULT_SERVER;
    int port = DEFAULT_PORT;

    // Create the UDP client socket
    int client_socket = socket(AF_INET, SOCK_DGRAM, 0);
    if (client_socket < 0) {
        errorhandler("Error creating socket");
        clearwinsock();
        return -1;
    }

    // Set server address and port
    struct sockaddr_in server_address;
    memset(&server_address, 0, sizeof(server_address));
    server_address.sin_family = AF_INET;
    server_address.sin_port = htons(port);

    // Resolve server address
    struct hostent *host = gethostbyname(server_name);
    if (host == NULL) {
        errorhandler("Error resolving host");
        clearwinsock();
        return EXIT_FAILURE;
    }

    memcpy(&server_address.sin_addr.s_addr, host->h_addr_list[0], host->h_length);

    printf("\n\nConnecting to server %s (IP: %s, port: %d)\n", server_name, inet_ntoa(*(struct in_addr *)host->h_addr), port);

    char response[BUFFMAX];
    socklen_t server_address_length = sizeof(server_address);
    request req;

    print_menu();
    printf("\n--- PASSWORD GENERATOR ---\n");
    while (1) {
        printf("\nEnter command: ");
        char input[BUFFMAX];
        memset(input, 0, BUFFMAX);
        fgets(input, BUFFMAX, stdin);

        // Remove the trailing newline from the user input
        input[strcspn(input, "\n")] = '\0';

        // Check for quit command
        if (input[0] == CMD_QUIT) {
            printf("Exiting the application.\n");
            break;
        }

        // Check for help command
        if (input[0] == CMD_HELP) {
            print_help_menu(); // Display the help menu
            continue;
        }

        // Parse command and length
        char command;
        int length;
        if (sscanf(input, "%c %d", &command, &length) != 2 || length < MIN_LENGTH || length > MAX_LENGTH) {
            printf("Invalid command or length. Use 'h' for help.\n");
            continue;
        }

        // Prepare the request structure
        req.request_type = command;
        req.length = length;
        memset(req.password, 0, sizeof(req.password));

        // Send the request to the server
        if (sendto(client_socket, (const char *)&req, sizeof(req), 0, (struct sockaddr *)&server_address, server_address_length) != sizeof(req)) {
            errorhandler("sendto() failed");
            break;
        }


        // Receive the server's response
        memset(response, 0, BUFFMAX);
        int recv_len = recvfrom(client_socket, response, BUFFMAX - 1, 0, (struct sockaddr *)&server_address, &server_address_length);
        if (recv_len < 0) {
            errorhandler("recvfrom() failed");
            break;
        }

        // Print the server's response
        response[recv_len] = '\0'; // Null-terminate the response
        printf("Server response: %s\n", response);
        printf("\n");
    }

    closesocket(client_socket); // Close the client socket
    clearwinsock(); // Clean up the Winsock library if using Windows
    return EXIT_SUCCESS;
}
