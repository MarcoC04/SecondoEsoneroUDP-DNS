#include "protocol.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#if defined WIN32
#include <winsock2.h> // Include winsock2.h before any other library on Windows
#include <ws2tcpip.h> // For TCP/IP utilities
#include <windows.h>   // For Windows-specific functions
#else
#include <arpa/inet.h>  // For internet socket functions on Unix-based systems
#include <unistd.h>      // For system calls like close()
#include <sys/socket.h>  // For socket operations
#include <netinet/in.h>  // For internet socket address structure
#include <netdb.h>       // For hostname resolution
#define closesocket close // On Unix, close() is used instead of closesocket()
#endif

// Function to clean up the Winsock library on Windows
void clearwinsock()
{
#if defined WIN32
    WSACleanup(); // Cleans up the Winsock library
#endif
}

// Function to handle errors by printing error messages
void errorhandler(const char *error_message)
{
    perror(error_message); // Prints the error message to stderr
}

// Function to display the main menu of the client
void print_menu()
{
    printf("Password Generator Menu\n");
    printf("Commands:\n");
    printf(" h        : show this help menu\n");
    printf(" n LENGTH : generate numeric password\n");
    printf(" a LENGTH : generate alphabetic password\n");
    printf(" m LENGTH : generate mixed password\n");
    printf(" s LENGTH : generate secure password\n");
    printf(" u LENGTH : generate unambiguous secure password\n");
    printf(" q        : quit application\n");
}

// Function to display the help menu with detailed descriptions of each command
void print_help_menu()
{
    printf("Password Generator Help Menu\n");
    printf("Commands:\n");
    printf(" h        : show this help menu\n");
    printf(" n LENGTH : generate numeric password (digits only)\n");
    printf(" a LENGTH : generate alphabetic password (lowercase letters)\n");
    printf(" m LENGTH : generate mixed password (lowercase letters and numbers)\n");
    printf(" s LENGTH : generate secure password (uppercase, lowercase, numbers, symbols)\n");
    printf(" u LENGTH : generate unambiguous secure password (no similar-looking characters)\n");
    printf(" q        : quit application\n");
    printf("\n LENGTH must be between %d and %d characters\n", MIN_LENGTH, MAX_LENGTH);
    printf("\nAmbiguous characters excluded in 'u' option:\n");
    printf(" 0 O o (zero and letters O)\n");
    printf(" 1 l I i (one and letters l, I)\n");
    printf(" 2 Z z (two and letter Z)\n");
    printf(" 5 S s (five and letter S)\n");
    printf(" 8 B (eight and letter B)\n");
}

int main()
{
#if defined WIN32
    // Initialize the Winsock library on Windows
    WSADATA wsa_data;
    if (WSAStartup(MAKEWORD(2, 2), &wsa_data) != 0)
    {
        printf("Error at WSAStartup()\n");
        return EXIT_FAILURE;
    }
#endif

    int client_socket;
    struct sockaddr_in server_address;
    char buffer[BUFFMAX];
    memset(buffer, 0, BUFFMAX);

    // Prompt the user to enter the server name and port
    printf("Enter the server name and port (in the format servername:port): ");
    fgets(buffer, BUFFMAX, stdin);

    // Parse the server name and port from the input
    char *delim = ":";
    char *server_name = strtok(buffer, delim); // Extract server name
    char *port_str = strtok(NULL, delim); // Extract port number
    if (!server_name || !port_str)
    {
        fprintf(stderr, "Invalid input format. Use servername:port.\n");
        clearwinsock();
        return EXIT_FAILURE;
    }

    // Convert the port string to an integer
    int port = atoi(port_str);
    if (port <= 0 || port > 65535)
    {
        fprintf(stderr, "Invalid port number.\n");
        clearwinsock();
        return EXIT_FAILURE;
    }

    // Resolve the server address using the provided server name
    struct hostent *host = gethostbyname(server_name);
    if (host == NULL)
    {
        errorhandler("Error resolving host");
        clearwinsock();
        return EXIT_FAILURE;
    }

    // Display the server connection information
    printf("Connecting to server %s (IP: %s, port: %d)\n", server_name, inet_ntoa(*(struct in_addr *)host->h_addr), port);

    // Create a UDP socket for the client
    if ((client_socket = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)) < 0)
    {
        errorhandler("socket() failed");
        clearwinsock();
        return EXIT_FAILURE;
    }

    memset(&server_address, 0, sizeof(server_address));
    server_address.sin_family = AF_INET; // IPv4
    server_address.sin_port = htons(port); // Port number in network byte order
    memcpy(&server_address.sin_addr, host->h_addr, host->h_length); // Copy server IP address

    char response[BUFFMAX];
    int server_address_length = sizeof(server_address); // Set the address length (int for compatibility on Windows)

    printf("Welcome to the Password Generator Client!\n");
    print_menu(); // Display the menu to the user

    while (1)
    {
        printf("\nEnter command: ");
        memset(buffer, 0, BUFFMAX);
        fgets(buffer, BUFFMAX, stdin);

        // Remove the trailing newline from the user input
        buffer[strcspn(buffer, "\n")] = '\0';

        // Check for quit command
        if (buffer[0] == CMD_QUIT)
        {
            printf("Exiting the application.\n");
            break;
        }

        // Check for help command
        if (buffer[0] == CMD_HELP)
        {
            print_help_menu(); // Display the help menu
            continue;
        }

        // Send the user command to the server
        if (sendto(client_socket, buffer, strlen(buffer), 0, (struct sockaddr *)&server_address, sizeof(server_address)) != strlen(buffer))
        {
            errorhandler("sendto() failed");
            break;
        }

        // Receive the server's response
        memset(response, 0, BUFFMAX);
        int recv_len = recvfrom(client_socket, response, BUFFMAX - 1, 0, (struct sockaddr *)&server_address, &server_address_length);
        if (recv_len < 0)
        {
            errorhandler("recvfrom() failed");
            break;
        }

        // Print the server's response
        printf("Server response: %s\n", response);
    }

    closesocket(client_socket); // Close the client socket
    clearwinsock(); // Clean up the Winsock library if using Windows
    return EXIT_SUCCESS;
}
