#ifndef PROTOCOL_H
#define PROTOCOL_H

#define BUFFMAX 255
#define SERVER_PORT 48000
#define SERVER_ADDRESS "127.0.0.1" // Default server address for localhost

// Minimum and maximum password length
#define MIN_LENGTH 6
#define MAX_LENGTH 32

// Commands
#define CMD_HELP 'h'
#define CMD_QUIT 'q'
#define CMD_NUMERIC 'n'
#define CMD_ALPHA 'a'
#define CMD_MIXED 'm'
#define CMD_SECURE 's'
#define CMD_UNAMBIGUOUS 'u'

#endif // PROTOCOL_H
