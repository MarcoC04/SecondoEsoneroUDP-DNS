#include "protocol.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#if defined WIN32
#include <winsock.h> // Windows specific socket library
#else
#include <arpa/inet.h>  // For socket functions on Unix-based systems
#include <unistd.h>      // For close() and other Unix-specific system calls
#include <sys/socket.h>  // For socket operations on Unix-based systems
#include <netinet/in.h>  // For internet socket addresses
#define closesocket close // Define closesocket for Unix-based systems (it's called close in Unix)
#endif

// Function to clean up the Winsock library on Windows
void clearwinsock()
{
#if defined WIN32
    WSACleanup(); // Cleans up Winsock library
#endif
}

// Function to handle errors and print error messages
void errorhandler(const char *error_message)
{
    perror(error_message); // Prints an error message to stderr
}

// Function to generate a numeric password
void generate_numeric(char *password, int length)
{
    for (int i = 0; i < length; i++)
        password[i] = '0' + rand() % 10; // Randomly selects digits from 0 to 9
    password[length] = '\0'; // Null-terminate the string
}

// Function to generate a password consisting of lowercase alphabetic characters
void generate_alpha(char *password, int length)
{
    for (int i = 0; i < length; i++)
        password[i] = 'a' + rand() % 26; // Randomly selects lowercase letters a to z
    password[length] = '\0'; // Null-terminate the string
}

// Function to generate a mixed password (lowercase letters and digits)
void generate_mixed(char *password, int length)
{
    for (int i = 0; i < length; i++)
    {
        if (rand() % 2)
            password[i] = 'a' + rand() % 26; // Randomly select lowercase letter
        else
            password[i] = '0' + rand() % 10; // Randomly select a digit
    }
    password[length] = '\0'; // Null-terminate the string
}

// Function to generate a secure password (uppercase, lowercase, digits, symbols)
void generate_secure(char *password, int length)
{
    const char *chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()";
    for (int i = 0; i < length; i++)
        password[i] = chars[rand() % strlen(chars)]; // Randomly selects from the characters
    password[length] = '\0'; // Null-terminate the string
}

// Function to generate an unambiguous secure password (excluding confusing characters)
void generate_unambiguous(char *password, int length)
{
    const char *chars = "ACDEFGHJKLMNPQRTUVWXYabcdefghjkmnpqrtuvwxy34679!@#$%^&*()";
    for (int i = 0; i < length; i++)
        password[i] = chars[rand() % strlen(chars)]; // Randomly selects from the unambiguous characters
    password[length] = '\0'; // Null-terminate the string
}

int main()
{
#if defined WIN32
    // Initialize Winsock on Windows
    WSADATA wsa_data;
    if (WSAStartup(MAKEWORD(2, 2), &wsa_data) != 0)
    {
        printf("Error at WSAStartup()\n"); // Error initializing Winsock
        return EXIT_FAILURE;
    }
#endif

    srand(time(NULL)); // Seed the random number generator

    int server_socket;
    // Create a UDP socket
    if ((server_socket = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)) < 0)
    {
        errorhandler("socket() failed"); // If socket creation fails, print error
        return EXIT_FAILURE;
    }

    struct sockaddr_in server_address, client_address;
    memset(&server_address, 0, sizeof(server_address)); // Clear server address structure
    server_address.sin_family = AF_INET; // IPv4 protocol
    server_address.sin_port = htons(DEFAULT_PORT); // Set port number
    server_address.sin_addr.s_addr = inet_addr(DEFAULT_IP); // Set IP address

    // Bind the server socket to the specified address and port
    if (bind(server_socket, (struct sockaddr *)&server_address, sizeof(server_address)) < 0)
    {
        errorhandler("bind() failed"); // Error in binding
        closesocket(server_socket); // Close the socket
        return EXIT_FAILURE;
    }

    printf("Server listening on port: %d\n", DEFAULT_PORT);

    request req;
    char response[BUFFMAX]; // Buffer to store the response

    while (1)
    {
        unsigned int client_address_length = sizeof(client_address);
        memset(&req, 0, sizeof(req)); // Clear the request structure

        // Receive client request
        int recv_len = recvfrom(server_socket, (char *)&req, sizeof(req), 0, (struct sockaddr *)&client_address, &client_address_length);
        if (recv_len < 0)
        {
            errorhandler("recvfrom() failed"); // Error receiving message
            continue;
        }

        // Print client info
        printf("New request from %s:%d\n", inet_ntoa(client_address.sin_addr), ntohs(client_address.sin_port));

        // Validate password length
        if (req.length < MIN_LENGTH || req.length > MAX_LENGTH)
        {
            snprintf(response, BUFFMAX, "Error: Length must be between %d and %d.\n", MIN_LENGTH, MAX_LENGTH);
        }
        else
        {
            // Generate the password based on the received command
            switch (req.request_type)
            {
            case CMD_NUMERIC:
                generate_numeric(req.password, req.length);
                break;
            case CMD_ALPHA:
                generate_alpha(req.password, req.length);
                break;
            case CMD_MIXED:
                generate_mixed(req.password, req.length);
                break;
            case CMD_SECURE:
                generate_secure(req.password, req.length);
                break;
            case CMD_UNAMBIGUOUS:
                generate_unambiguous(req.password, req.length);
                break;
            default:
                snprintf(response, BUFFMAX, "Error: Unknown command.\n"); // Invalid command
                sendto(server_socket, response, strlen(response), 0, (struct sockaddr *)&client_address, client_address_length);
                continue;
            }
            snprintf(response, BUFFMAX, "%s", req.password); // Store the generated password in response
        }

        // Send the generated password back to the client
        sendto(server_socket, response, strlen(response), 0, (struct sockaddr *)&client_address, client_address_length);
    }

    // Close the server socket and clean up Winsock if on Windows
    closesocket(server_socket);
    clearwinsock();
    return EXIT_SUCCESS;
}
